## Website Performance Optimization portfolio project


### Getting started

####Acces the index.html file to view the page, there are subsiquent page to view profiles and your pizza preferences as well.

